// Catálogo de productos (Forma C - Catálogo y Tarifas)
const productos = [
  {codigo:'CL001', categoria:'Cilindros de Gas', nombre:'Cilindro GLP 5 kg', descripcion:'Cilindro de gas licuado de petróleo 5 kg. Para uso residencial (cocina, calefacción pequeña).', unidad:'Unidad', precioResidencial:6500, precioComercial:6000, stock:80, stockCritico:10},
  {codigo:'CL002', categoria:'Cilindros de Gas', nombre:'Cilindro GLP 11 kg', descripcion:'Cilindro estándar doméstico. El más utilizado en hogares chilenos. Compatible con reguladores estándar.', unidad:'Unidad', precioResidencial:12000, precioComercial:11000, stock:200, stockCritico:20},
  {codigo:'CL003', categoria:'Cilindros de Gas', nombre:'Cilindro GLP 15 kg', descripcion:'Cilindro de mayor capacidad para hogares de alto consumo o locales pequeños.', unidad:'Unidad', precioResidencial:16000, precioComercial:14500, stock:90, stockCritico:15},
  {codigo:'CL004', categoria:'Cilindros de Gas', nombre:'Cilindro GLP 45 kg', descripcion:'Cilindro industrial. Uso comercial: restaurantes, talleres, calefacción de locales.', unidad:'Unidad', precioResidencial:45000, precioComercial:40000, stock:30, stockCritico:5},
  {codigo:'RG001', categoria:'Reguladores', nombre:'Regulador doméstico estándar', descripcion:'Regulador de 1 etapa para cilindros 5, 11 y 15 kg. Presión de salida 28 mbar.', unidad:'Unidad', precioResidencial:8990, precioComercial:8200, stock:45, stockCritico:8},
  {codigo:'RG002', categoria:'Reguladores', nombre:'Regulador de alta presión', descripcion:'Regulador para cocinas industriales o equipos de mayor consumo. Presión regulable.', unidad:'Unidad', precioResidencial:18990, precioComercial:17000, stock:12, stockCritico:5},
  {codigo:'RG003', categoria:'Reguladores', nombre:'Regulador dual (2 salidas)', descripcion:'Permite conectar dos artefactos simultáneamente al mismo cilindro.', unidad:'Unidad', precioResidencial:14990, precioComercial:13500, stock:18, stockCritico:5},
  {codigo:'MG001', categoria:'Mangueras y Conexiones', nombre:'Manguera gas 1.5 m', descripcion:'Manguera flexible homologada. Diámetro interior 9mm. Compatible con reguladores estándar.', unidad:'Unidad', precioResidencial:3990, precioComercial:3500, stock:80, stockCritico:10},
  {codigo:'MG002', categoria:'Mangueras y Conexiones', nombre:'Manguera gas 3 m', descripcion:'Manguera larga para instalaciones donde el artefacto está alejado del cilindro.', unidad:'Unidad', precioResidencial:6990, precioComercial:6200, stock:50, stockCritico:10},
  {codigo:'MG003', categoria:'Mangueras y Conexiones', nombre:'Abrazadera metálica', descripcion:'Abrazadera de acero para asegurar la conexión manguera-regulador y manguera-artefacto.', unidad:'Unidad', precioResidencial:990, precioComercial:800, stock:200, stockCritico:30},
  {codigo:'MG004', categoria:'Mangueras y Conexiones', nombre:'Kit conexión completo', descripcion:'Todo lo necesario para instalar un cilindro nuevo (regulador + manguera 1.5m + abrazaderas).', unidad:'Kit', precioResidencial:12990, precioComercial:11500, stock:25, stockCritico:5},
  {codigo:'AC001', categoria:'Accesorios', nombre:'Carro porta cilindro 11/15 kg', descripcion:'Carro metálico con ruedas para transportar cilindros dentro del hogar con seguridad.', unidad:'Unidad', precioResidencial:12990, precioComercial:11000, stock:20, stockCritico:5},
  {codigo:'AC002', categoria:'Accesorios', nombre:'Tapa protectora para válvula', descripcion:'Tapa de plástico ABS para proteger la válvula del cilindro durante el transporte.', unidad:'Unidad', precioResidencial:1490, precioComercial:1200, stock:60, stockCritico:10},
  {codigo:'AC003', categoria:'Accesorios', nombre:'Detector de gas a batería', descripcion:'Sensor electroquímico. Alarma sonora y visual ante fuga de gas GLP o metano.', unidad:'Unidad', precioResidencial:19990, precioComercial:17000, stock:8, stockCritico:3},
];

// Zonas de cobertura y despacho
const zonas = [
  {zona:'Zona Centro', comunas:'Chillán (sectores centro, norte y sur)', dias:'Lunes a Sábado', horario:'08:00 – 20:00', tiempo:'1 – 3 horas'},
  {zona:'Zona Oriente', comunas:'Chillán (sector oriente), Chillán Viejo', dias:'Lunes a Viernes', horario:'08:00 – 18:00', tiempo:'2 – 4 horas'},
  {zona:'Zona Rural', comunas:'El Carmen, Pinto, San Ignacio', dias:'Martes y Jueves', horario:'08:00 – 16:00', tiempo:'3 – 6 horas'},
  {zona:'Zona Sur', comunas:'Bulnes, Quillón', dias:'Miércoles', horario:'08:00 – 16:00', tiempo:'4 – 6 horas'},
  {zona:'Zona Comercial', comunas:'Parques industriales y locales comerciales', dias:'Lunes a Viernes', horario:'07:00 – 17:00', tiempo:'Según agenda'},
];

// Regiones y comunas (para selects dependientes)
const regiones = {
  'Región de Ñuble': ['Chillán','Chillán Viejo','San Carlos','Bulnes','El Carmen','Pinto','San Ignacio','Quillón'],
  'Región Metropolitana de Santiago': ['Santiago','Providencia','Las Condes','Maipú'],
  'Región del Biobío': ['Concepción','Talcahuano','Los Ángeles'],
};

// Usuarios de demostración (sirven para poblar el listado del administrador y para
// iniciar sesión de prueba; no hay backend real, todo se guarda en localStorage).
// Credenciales de prueba:
//   Administrador -> marcela.fuentes@gmail.com / admin123
//   Vendedor      -> pedro.salazar@duoc.cl     / vendedor1
//   Cliente       -> fer.nunez@gmail.com       / cliente1
const usuariosDemo = [
  {run:'191234567', nombre:'Marcela', apellidos:'Fuentes Rojas', correo:'marcela.fuentes@gmail.com', clave:'admin123', tipo:'Administrador', region:'Región de Ñuble', comuna:'Chillán', direccion:'Av. Libertad 450'},
  {run:'182345678', nombre:'Pedro', apellidos:'Salazar Ibáñez', correo:'pedro.salazar@duoc.cl', clave:'vendedor1', tipo:'Vendedor', region:'Región de Ñuble', comuna:'Chillán Viejo', direccion:'Los Aromos 120'},
  {run:'201122334', nombre:'Fernanda', apellidos:'Núñez Soto', correo:'fer.nunez@gmail.com', clave:'cliente1', tipo:'Cliente', region:'Región de Ñuble', comuna:'Bulnes', direccion:'Camino Real 890'},
];

// Mapa de imágenes reales de cada producto (archivo dentro de /img)
const imagenesProductos = {
  CL001: 'CL001.jpg',
  CL002: 'CL002.jpg',
  CL003: 'CL003.jpg',
  CL004: 'CL004.jpg',
  RG001: 'RG001.jpg',
  RG002: 'RG002.jpeg',
  RG003: 'RG003.webp',
  MG001: 'MG001.webp',
  MG002: 'MG002.webp',
  MG003: 'MG003.webp',
  MG004: 'MG004.webp',
  AC001: 'AC001.jpg',
  AC002: 'AC002.jpg',
  AC003: 'AC003.jpg',
};

// Devuelve la imagen real del producto si existe; si no, cae al ícono SVG genérico
function mediaProducto(p){
  const archivo = imagenesProductos[p.codigo];
  if(archivo){
    return `<img src="img/${archivo}" alt="${p.nombre}" class="img-producto" loading="lazy">`;
  }
  return iconoProducto(p);
}

// Ícono SVG reutilizable de cilindro de gas, con marca "GasPro" impresa y tamaño según los kg
function iconoCilindro(color, kg){
  kg = kg || 11;
  const escala = {5:0.62, 11:0.82, 15:0.95, 45:1.25}[kg] || 0.82;
  const bodyW = Math.round(34*escala);
  const bodyH = Math.round(42*escala);
  const x = Math.round(32 - bodyW/2);
  const y = Math.round(54 - bodyH);
  const valveW = Math.round(bodyW*0.3);
  const bandY = Math.round(y + bodyH*0.36);
  const bandH = Math.round(bodyH*0.26);
  const fontMarca = Math.max(5, Math.round(6*escala + 3));
  return `<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="${32-valveW/2}" y="${y-9}" width="${valveW}" height="9" rx="1.5" fill="${color}"/>
    <rect x="${x}" y="${y}" width="${bodyW}" height="${bodyH}" rx="6" fill="${color}"/>
    <rect x="${x}" y="${bandY}" width="${bodyW}" height="${bandH}" fill="#ffffff"/>
    <text x="32" y="${bandY + bandH/2 + fontMarca*0.35}" font-family="Arial, Helvetica, sans-serif" font-size="${fontMarca}" font-weight="800" fill="${color}" text-anchor="middle">GasPro</text>
    <text x="32" y="${y + bodyH - 5}" font-family="Arial, Helvetica, sans-serif" font-size="6" fill="#ffffff" text-anchor="middle" opacity=".9">${kg} kg</text>
  </svg>`;
}

// Ícono de regulador de gas
function iconoRegulador(color){
  return `<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="24" cy="26" r="16" fill="${color}"/>
    <circle cx="24" cy="26" r="9" fill="#ffffff" opacity=".9"/>
    <circle cx="24" cy="26" r="3" fill="${color}"/>
    <rect x="38" y="22" width="18" height="8" rx="3" fill="${color}"/>
    <rect x="50" y="18" width="8" height="16" rx="2" fill="${color}"/>
    <text x="32" y="52" font-family="Arial, Helvetica, sans-serif" font-size="8" font-weight="700" fill="${color}" text-anchor="middle">Regulador</text>
  </svg>`;
}

// Ícono de manguera / conexión de gas
function iconoManguera(color){
  return `<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M8 22 C 8 10, 26 10, 26 22 C 26 34, 44 34, 44 22 C 44 10, 58 10, 58 22"
          stroke="${color}" stroke-width="6" fill="none" stroke-linecap="round"/>
    <rect x="4" y="36" width="14" height="10" rx="2" fill="${color}"/>
    <rect x="46" y="36" width="14" height="10" rx="2" fill="${color}"/>
    <text x="32" y="56" font-family="Arial, Helvetica, sans-serif" font-size="8" font-weight="700" fill="${color}" text-anchor="middle">Conexión</text>
  </svg>`;
}

// Íconos de accesorios (carro, tapa protectora, detector de gas)
function iconoAccesorio(color, codigo){
  if(codigo === 'AC001'){
    return `<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="20" y="8" width="16" height="28" rx="4" fill="${color}"/>
      <line x1="12" y1="12" x2="20" y2="12" stroke="${color}" stroke-width="4"/>
      <line x1="12" y1="12" x2="12" y2="38" stroke="${color}" stroke-width="4"/>
      <line x1="12" y1="38" x2="36" y2="38" stroke="${color}" stroke-width="4"/>
      <circle cx="18" cy="48" r="6" fill="${color}"/>
      <circle cx="34" cy="48" r="6" fill="${color}"/>
      <text x="32" y="60" font-family="Arial, Helvetica, sans-serif" font-size="8" font-weight="700" fill="${color}" text-anchor="middle">Carro</text>
    </svg>`;
  }
  if(codigo === 'AC002'){
    return `<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="26" r="18" fill="${color}"/>
      <circle cx="32" cy="26" r="10" fill="#ffffff" opacity=".85"/>
      <text x="32" y="54" font-family="Arial, Helvetica, sans-serif" font-size="8" font-weight="700" fill="${color}" text-anchor="middle">Tapa</text>
    </svg>`;
  }
  return `<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="16" y="10" width="32" height="24" rx="4" fill="${color}"/>
    <circle cx="32" cy="22" r="6" fill="#ffffff"/>
    <path d="M14 40 q18 -10 36 0" stroke="${color}" stroke-width="3" fill="none"/>
    <text x="32" y="56" font-family="Arial, Helvetica, sans-serif" font-size="8" font-weight="700" fill="${color}" text-anchor="middle">Detector</text>
  </svg>`;
}

// Selector automático de ícono según categoría/producto
function iconoProducto(p, color){
  color = color || '#4b1f7a';
  if(p.categoria === 'Cilindros de Gas'){
    const match = p.nombre.match(/(\d+)\s*kg/i);
    const kg = match ? parseInt(match[1]) : 11;
    return iconoCilindro(color, kg);
  }
  if(p.categoria === 'Reguladores') return iconoRegulador(color);
  if(p.categoria === 'Mangueras y Conexiones') return iconoManguera(color);
  if(p.categoria === 'Accesorios') return iconoAccesorio(color, p.codigo);
  return iconoCilindro(color, 11);
}
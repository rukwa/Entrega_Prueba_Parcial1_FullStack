// Valida que el correo tenga uno de los dominios permitidos
function validarCorreo(correo){
  const dominiosPermitidos = ['duoc.cl','profesor.duoc.cl','gmail.com'];
  const match = correo.match(/^[^\s@]+@([^\s@]+\.[^\s@]+)$/);
  if(!match) return false;
  return dominiosPermitidos.includes(match[1].toLowerCase());
}

// Valida RUN chileno sin puntos ni guion (ej: 19011022K), dígito verificador módulo 11
function validarRut(valor){
  const rut = valor.trim().toUpperCase();
  if(!/^[0-9]{6,8}[0-9K]$/.test(rut)) return false;
  const cuerpo = rut.slice(0,-1);
  const dv = rut.slice(-1);
  let suma = 0, multiplo = 2;
  for(let i = cuerpo.length - 1; i >= 0; i--){
    suma += parseInt(cuerpo[i],10) * multiplo;
    multiplo = multiplo === 7 ? 2 : multiplo + 1;
  }
  const resto = 11 - (suma % 11);
  const dvEsperado = resto === 11 ? '0' : resto === 10 ? 'K' : String(resto);
  return dv === dvEsperado;
}

function marcarInvalido(input, mensaje){
  input.classList.add('is-invalid');
  input.classList.remove('is-valid');
  const fb = input.parentElement.querySelector('.invalid-feedback');
  if(fb) fb.textContent = mensaje;
}

function marcarValido(input){
  input.classList.remove('is-invalid');
  input.classList.add('is-valid');
}

function contadorCaracteres(input, max){
  const hint = input.parentElement.querySelector('.sugerencia');
  if(hint) hint.textContent = `${input.value.length}/${max} caracteres`;
}
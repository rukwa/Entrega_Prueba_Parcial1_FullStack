// ===== Sistema de usuarios y sesión (localStorage) =====
// No hay backend real: los usuarios registrados y la sesión activa se guardan
// en el navegador (localStorage), pero ya funcionan las validaciones de
// correo/clave y las redirecciones según el tipo de usuario (Administrador,
// Vendedor o Cliente).

const USERS_KEY = 'gaspro_usuarios';
const SESSION_KEY = 'gaspro_sesion';

// La primera vez que se carga el sitio en un navegador, copia los usuarios
// de demostración (data.js) al localStorage. Si ya existen (porque el
// usuario ya se registró o un admin ya editó algo), no se pisan.
function inicializarUsuarios(){
  if(!localStorage.getItem(USERS_KEY)){
    localStorage.setItem(USERS_KEY, JSON.stringify(usuariosDemo));
  }
}

function obtenerUsuarios(){
  inicializarUsuarios();
  try{
    return JSON.parse(localStorage.getItem(USERS_KEY)) || [];
  }catch(e){
    return [];
  }
}

function guardarUsuarios(lista){
  localStorage.setItem(USERS_KEY, JSON.stringify(lista));
}

function buscarUsuarioPorCorreo(correo){
  const c = (correo || '').trim().toLowerCase();
  return obtenerUsuarios().find(u => u.correo.toLowerCase() === c);
}

function buscarUsuarioPorRun(run){
  return obtenerUsuarios().find(u => u.run === run);
}

function registrarUsuario(usuario){
  const lista = obtenerUsuarios();
  lista.push(usuario);
  guardarUsuarios(lista);
}

function actualizarUsuario(run, cambios){
  const lista = obtenerUsuarios();
  const idx = lista.findIndex(u => u.run === run);
  if(idx > -1){
    lista[idx] = { ...lista[idx], ...cambios };
    guardarUsuarios(lista);
    // Si el usuario editado es el que tiene la sesión abierta, refrescamos la sesión
    const sesion = obtenerSesion();
    if(sesion && sesion.run === run) iniciarSesion(lista[idx]);
  }
}

// ----- Sesión activa -----
function iniciarSesion(usuario){
  localStorage.setItem(SESSION_KEY, JSON.stringify({
    run: usuario.run,
    nombre: usuario.nombre,
    apellidos: usuario.apellidos,
    correo: usuario.correo,
    tipo: usuario.tipo
  }));
}

function obtenerSesion(){
  try{
    return JSON.parse(localStorage.getItem(SESSION_KEY));
  }catch(e){
    return null;
  }
}

function cerrarSesion(){
  localStorage.removeItem(SESSION_KEY);
  window.location.href = 'Index.html';
}

// Redirige tras un login o registro exitoso según el tipo de usuario
function redirigirSegunTipo(tipo){
  if(tipo === 'Administrador' || tipo === 'Vendedor'){
    window.location.href = 'AdminHome.html';
  } else {
    window.location.href = 'Index.html';
  }
}

// Protege las páginas del panel de administración.
// Si no hay sesión o el tipo de usuario no está permitido, redirige a Login.
// tiposPermitidos por defecto: Administrador y Vendedor pueden entrar al panel.
function exigirSesionAdmin(tiposPermitidos = ['Administrador', 'Vendedor']){
  const sesion = obtenerSesion();
  if(!sesion || !tiposPermitidos.includes(sesion.tipo)){
    window.location.href = 'Login.html';
    return null;
  }
  return sesion;
}

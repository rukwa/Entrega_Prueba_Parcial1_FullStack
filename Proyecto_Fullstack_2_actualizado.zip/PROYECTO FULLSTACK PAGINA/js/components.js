function paginaActiva(nombre){ return window.location.pathname.endsWith(nombre) ? 'active' : ''; }

function logoGasPro(size=32){
  return `<svg width="${size}" height="${size}" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
    <rect x="2" y="2" width="44" height="44" rx="10" fill="#ff4d1c"/>
    <path d="M14 32V16h5.5l4.8 8.4L29 16h5v16h-4.6V22.6l-4.9 8.4h-1l-4.9-8.4V32H14z" fill="#0d1321"/>
  </svg>`;
}

function renderHeader(active){
  const sesion = obtenerSesion();

  const linkPanel = (sesion && (sesion.tipo === 'Administrador' || sesion.tipo === 'Vendedor'))
    ? `<li class="nav-item"><a class="nav-link" href="AdminHome.html">⚙️ Panel admin</a></li>`
    : '';

  const linksSesion = sesion
    ? `<li class="nav-item"><span class="nav-link disabled">Hola, ${sesion.nombre}</span></li>
       <li class="nav-item"><a class="nav-link" href="#" onclick="cerrarSesion();return false;">Cerrar sesión</a></li>`
    : `<li class="nav-item"><a class="nav-link ${active==='login'?'active':''}" href="Login.html">Iniciar sesión</a></li>
       <li class="nav-item"><a class="nav-link ${active==='registro'?'active':''}" href="Registro.html">Registrarse</a></li>`;

  document.getElementById('site-header').innerHTML = `
  <nav class="navbar navbar-expand-lg navbar-gas fixed-top">
    <div class="container">
      <a class="navbar-brand" href="Index.html">${logoGasPro(30)} GasPro</a>
      <button class="navbar-toggler bg-light" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navMenu">
        <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-2">
          <li class="nav-item"><a class="nav-link ${active==='home'?'active':''}" href="Index.html">Home</a></li>
          <li class="nav-item"><a class="nav-link ${active==='productos'?'active':''}" href="Productos.html">Productos</a></li>
          <li class="nav-item"><a class="nav-link ${active==='nosotros'?'active':''}" href="Nosotros.html">Nosotros</a></li>
          <li class="nav-item"><a class="nav-link ${active==='blogs'?'active':''}" href="Blogs.html">Blogs</a></li>
          <li class="nav-item"><a class="nav-link ${active==='contacto'?'active':''}" href="Contacto.html">Contacto</a></li>
          ${linkPanel}
          ${linksSesion}
          <li class="nav-item"><a class="nav-link cart-link ${active==='carrito'?'active':''}" href="Carrito.html">
            🛒 Carrito <span id="cart-badge">0</span>
          </a></li>
        </ul>
      </div>
    </div>
  </nav>`;
  actualizarBadgeCarrito();
}

function renderFooter(){
  document.getElementById('site-footer').innerHTML = `
  <footer class="footer-gas">
    <div class="container row gy-3">
      <div class="col-md-4">
        <h6>GasPro</h6>
        <p class="small mb-0">Distribuidora de gas licuado a domicilio en Chillán, Región de Ñuble, desde 1998.</p>
      </div>
      <div class="col-md-4">
        <h6>Navegación</h6>
        <a href="Productos.html" class="d-block small">Productos</a>
        <a href="Nosotros.html" class="d-block small">Nosotros</a>
        <a href="Contacto.html" class="d-block small">Contacto</a>
      </div>
      <div class="col-md-4">
        <h6>Contacto</h6>
        <p class="small mb-0">📍 Chillán, Región de Ñuble<br>☎️ +56 9 0000 0000</p>
      </div>
    </div>
    <div class="text-center small mt-3 pt-3 border-top border-light border-opacity-25">
      © 2026 GasPro. Todos los derechos reservados.
    </div>
  </footer>`;
}

function renderAdminSidebar(active){
  const sesion = obtenerSesion();
  const esAdministrador = sesion && sesion.tipo === 'Administrador';

  const linkUsuarios = esAdministrador
    ? `<a href="AdminUsuarios.html" class="${active==='usuarios'?'active':''}">👤 Usuarios</a>`
    : '';

  document.getElementById('admin-sidebar').innerHTML = `
    <div class="text-center mb-4">
      <a href="Index.html" class="text-decoration-none text-white fw-bold d-flex align-items-center justify-content-center gap-2">${logoGasPro(26)} GasPro</a>
      <div class="small text-white-50">Panel ${sesion ? sesion.tipo : 'Administrador'}</div>
      ${sesion ? `<div class="small text-white-50">${sesion.nombre} ${sesion.apellidos}</div>` : ''}
    </div>
    <a href="AdminHome.html" class="${active==='home'?'active':''}">🏠 Inicio</a>
    <a href="AdminProductos.html" class="${active==='productos'?'active':''}">📦 Productos</a>
    ${linkUsuarios}
    <a href="#" onclick="cerrarSesion();return false;" class="mt-3 border-top border-light border-opacity-25 pt-3">🚪 Cerrar sesión</a>
  `;
}

// ===== Carrito de compras (localStorage) =====
const CART_KEY = 'gaspro_carrito';
function obtenerCarrito(){ return JSON.parse(localStorage.getItem(CART_KEY) || '[]'); }
function guardarCarrito(carrito){ localStorage.setItem(CART_KEY, JSON.stringify(carrito)); actualizarBadgeCarrito(); }
function actualizarBadgeCarrito(){
  const el = document.getElementById('cart-badge');
  if(el) el.textContent = obtenerCarrito().reduce((s,i)=>s+i.cantidad,0);
}
function agregarAlCarrito(codigo, cantidad = 1){
  const prod = productos.find(p => p.codigo === codigo);
  if(!prod) return;
  const carrito = obtenerCarrito();
  const existente = carrito.find(i => i.codigo === codigo);
  if(existente) existente.cantidad += cantidad;
  else carrito.push({codigo, cantidad});
  guardarCarrito(carrito);
  mostrarToast(`${prod.nombre} añadido al carrito`);
}
function mostrarToast(mensaje){
  const toast = document.createElement('div');
  toast.className = 'toast-gas';
  toast.textContent = mensaje;
  document.body.appendChild(toast);
  setTimeout(()=>toast.classList.add('show'), 50);
  setTimeout(()=>{ toast.classList.remove('show'); setTimeout(()=>toast.remove(), 300); }, 2200);
}